#include <immintrin.h>
#include <zmmintrin.h>
static __forceinline __m512 __load64(const __m512 *restrict p) 
{
  return _mm512_load_ps(p);
}
static __forceinline void __store64(__m512 * restrict p, __m512 v)  
{
  _mm512_store_ps(p, v);
}

  extern "C"
int saxpy(__m512 _a, __m512 * restrict x, __m512 * restrict y, __m512 * restrict z)
{
#ifdef SLOW
#define STORE __store64
#define LOAD __load64
#else
#define STORE(p,v) _mm512_store_ps(p,v)
#define LOAD(p) _mm512_load_ps(p)
#endif

  int i = 0;

  STORE(&z[0] , _mm512_add_ps(LOAD(&y[0]), _mm512_mul_ps(_a,LOAD(&x[0]))));
  STORE(&z[1] , _mm512_add_ps(LOAD(&y[1]), _mm512_mul_ps(_a,LOAD(&x[1]))));
  STORE(&z[2] , _mm512_add_ps(LOAD(&y[2]), _mm512_mul_ps(_a,LOAD(&x[2]))));
  STORE(&z[3] , _mm512_add_ps(LOAD(&y[3]), _mm512_mul_ps(_a,LOAD(&x[3]))));
  STORE(&z[4] , _mm512_add_ps(LOAD(&y[4]), _mm512_mul_ps(_a,LOAD(&x[4]))));
  STORE(&z[5] , _mm512_add_ps(LOAD(&y[5]), _mm512_mul_ps(_a,LOAD(&x[5]))));
  STORE(&z[6] , _mm512_add_ps(LOAD(&y[6]), _mm512_mul_ps(_a,LOAD(&x[6]))));
  STORE(&z[7] , _mm512_add_ps(LOAD(&y[7]), _mm512_mul_ps(_a,LOAD(&x[7]))));
  i+=8;

  STORE(&z[8+0] , _mm512_add_ps(LOAD(&y[8+0]), _mm512_mul_ps(_a,LOAD(&x[8+0]))));
  STORE(&z[8+1] , _mm512_add_ps(LOAD(&y[8+1]), _mm512_mul_ps(_a,LOAD(&x[8+1]))));
  STORE(&z[8+2] , _mm512_add_ps(LOAD(&y[8+2]), _mm512_mul_ps(_a,LOAD(&x[8+2]))));
  STORE(&z[8+3] , _mm512_add_ps(LOAD(&y[8+3]), _mm512_mul_ps(_a,LOAD(&x[8+3]))));
  STORE(&z[8+4] , _mm512_add_ps(LOAD(&y[8+4]), _mm512_mul_ps(_a,LOAD(&x[8+4]))));
  STORE(&z[8+5] , _mm512_add_ps(LOAD(&y[8+5]), _mm512_mul_ps(_a,LOAD(&x[8+5]))));
  STORE(&z[8+6] , _mm512_add_ps(LOAD(&y[8+6]), _mm512_mul_ps(_a,LOAD(&x[8+6]))));
  STORE(&z[8+7] , _mm512_add_ps(LOAD(&y[8+7]), _mm512_mul_ps(_a,LOAD(&x[8+7]))));
  i+=8;

  STORE(&z[16+0] , _mm512_add_ps(LOAD(&y[16+0]), _mm512_mul_ps(_a,LOAD(&x[16+0]))));
  STORE(&z[16+1] , _mm512_add_ps(LOAD(&y[16+1]), _mm512_mul_ps(_a,LOAD(&x[16+1]))));
  STORE(&z[16+2] , _mm512_add_ps(LOAD(&y[16+2]), _mm512_mul_ps(_a,LOAD(&x[16+2]))));
  STORE(&z[16+3] , _mm512_add_ps(LOAD(&y[16+3]), _mm512_mul_ps(_a,LOAD(&x[16+3]))));
  STORE(&z[16+4] , _mm512_add_ps(LOAD(&y[16+4]), _mm512_mul_ps(_a,LOAD(&x[16+4]))));
  STORE(&z[16+5] , _mm512_add_ps(LOAD(&y[16+5]), _mm512_mul_ps(_a,LOAD(&x[16+5]))));
  STORE(&z[16+6] , _mm512_add_ps(LOAD(&y[16+6]), _mm512_mul_ps(_a,LOAD(&x[16+6]))));
  STORE(&z[16+7] , _mm512_add_ps(LOAD(&y[16+7]), _mm512_mul_ps(_a,LOAD(&x[16+7]))));
  i+=8;

  STORE(&z[24+0] , _mm512_add_ps(LOAD(&y[24+0]), _mm512_mul_ps(_a,LOAD(&x[24+0]))));
  STORE(&z[24+1] , _mm512_add_ps(LOAD(&y[24+1]), _mm512_mul_ps(_a,LOAD(&x[24+1]))));
  STORE(&z[24+2] , _mm512_add_ps(LOAD(&y[24+2]), _mm512_mul_ps(_a,LOAD(&x[24+2]))));
  STORE(&z[24+3] , _mm512_add_ps(LOAD(&y[24+3]), _mm512_mul_ps(_a,LOAD(&x[24+3]))));
  STORE(&z[24+4] , _mm512_add_ps(LOAD(&y[24+4]), _mm512_mul_ps(_a,LOAD(&x[24+4]))));
  STORE(&z[24+5] , _mm512_add_ps(LOAD(&y[24+5]), _mm512_mul_ps(_a,LOAD(&x[24+5]))));
  STORE(&z[24+6] , _mm512_add_ps(LOAD(&y[24+6]), _mm512_mul_ps(_a,LOAD(&x[24+6]))));
  STORE(&z[24+7] , _mm512_add_ps(LOAD(&y[24+7]), _mm512_mul_ps(_a,LOAD(&x[24+7]))));
  i+=8;

  return i;
}

