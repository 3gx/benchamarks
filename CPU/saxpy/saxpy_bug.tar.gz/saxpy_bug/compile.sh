#!/bin/sh
icc -O3 -restrict -mmic -o saxpy_slow -DSLOW saxpy.cpp saxpy_kernel.cpp -openmp
icc -O3 -restrict -mmic -o saxpy_fast        saxpy.cpp saxpy_kernel.cpp -openmp
export MIC_KMP_AFFINITY=compact,verbose
export MIC_KMP_AFFINITY=compact
export MIC_KMP_PLACE_THREADS=1c4t10o
export MICRUN_HOST=node1-mic0
echo "slow"
./micrun ./saxpy_slow 2
echo "fast"
./micrun ./saxpy_fast 2

