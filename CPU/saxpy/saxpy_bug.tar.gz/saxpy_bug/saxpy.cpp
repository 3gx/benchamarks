#include <immintrin.h>
#include <zmmintrin.h>
#include <cstdlib>
#include <cstdio>
#include <sys/time.h>
#include <omp.h>
#include <cassert>

static double rtc(void)
{
  struct timeval Tvalue;
  double etime;
  struct timezone dummy;

  gettimeofday(&Tvalue,&dummy);
  etime =  (double) Tvalue.tv_sec +
    1.e-6*((double) Tvalue.tv_usec);
  return etime;
}


  extern "C"
int saxpy(__m512 _a, __m512 * restrict x, __m512 * restrict y, __m512 * restrict z);

int main(int argc, char * argv[])
{
  const int nthreads = argc > 1? atoi(argv[1]) : 4;

  double net_bw = 0.0;
#pragma omp parallel num_threads(nthreads)
  {
    __m512 *x,*y,*z;
    const int n0 = 16*8*64;
#pragma omp critical
    {
      x = (__m512*)_mm_malloc(n0*sizeof(float),64);
      y = (__m512*)_mm_malloc(n0*sizeof(float),64);
      z = (__m512*)_mm_malloc(n0*sizeof(float),64);
    }
    for (int i= 0; i < 8; i++)
      x[i] = y[i] = z[i] = _mm512_set1_ps(drand48());
    const float a = drand48();
    __m512 _a = _mm512_set1_ps(a);

    int n;
    n= saxpy(_a, x, y, z);
    assert(n*16 <= n0);
    n= saxpy(_a, x, y, z);
    n= saxpy(_a, x, y, z);
    n= saxpy(_a, x, y, z);

#pragma omp barrier
    const double t0 = rtc();
    const int nrep = 40000;
    asm("#saxpy-beg");
    for (int r= 0; r < nrep; r++)
    {
      n = saxpy(_a, x, y, z);
    }
    asm("#saxpy-end");
    const double t1 = rtc();
#pragma omp barrier

    const double dt = t1 - t0;
    const double bw = (3.0*n*16)*nrep*sizeof(float)/dt/1e9;

#pragma omp critical
    net_bw += bw;

#pragma omp barrier
    fprintf(stderr,  "tid= %d  done in %g sec  BW= %g  GB/s \n",
        omp_get_thread_num(),
        dt,
        bw);



    _mm_free(x);
    _mm_free(y);
    _mm_free(z);
  }
  fprintf(stderr ," aggregate BW= %g \n", net_bw);

}
